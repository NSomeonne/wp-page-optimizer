# 🚀 Page Optimizer Pro v2.0.1

Wtyczka WordPress optymalizująca wydajność strony + AI + SEO + Naprawa.

## ✨ Główne funkcje

### 🤖 AI Integration
- **OpenAI (ChatGPT)** – Auto-generowanie treści i optymalizacja SEO
- **Anthropic (Claude)** – Zaawansowana analiza tekstu
- **Google Gemini** – Szybkie przetwarzanie danych
- **Cohere** – Alternatywny dostawca AI

### 🔍 SEO Optimization
- Meta tagi (title, description, keywords)
- Schema.org strukturalne dane (JSON-LD)
- Open Graph & Twitter Card
- Automatyczny XML Sitemap

### 🔧 Site Repair
- Czyszczenie blokad edycji z bazy danych
- Usuwanie sierocych wpisów postmeta
- Naprawa uprawnień cache
- Diagnostyka zdrowia strony (PHP, WP, rozmiar BD, debug.log)

### ⚡ Performance
- Asynchroniczny CSS z `<noscript>` fallbackiem (FCP boost)
- Defer JS z ochroną jQuery
- Lazy Loading obrazów
- Nagłówki Browser Cache + bezpieczeństwa (`X-Frame-Options`, `Referrer-Policy`)

## 📥 Instalacja

1. Skompresuj zawartość repozytorium do pliku `.zip` (**nie główny folder, lecz pliki wewnątrz!**).
2. Zaloguj się do `wp-admin` → Wtyczki → Dodaj nową → Wyślij na serwer.
3. Wybierz plik `.zip` i kliknij **Instaluj**.
4. Aktywuj wtyczkę.

Przy pierwszej aktywacji wtyczka automatycznie ustawi zalecane wartości domyślne.

## 🔧 Wymagania

- WordPress 5.0+
- PHP 7.4+

## 📝 Licencja

GPL v2 lub nowsza

## 👤 Autor

Norbert Siedlecki  
<https://github.com/norbertsiedlecki-prog>
